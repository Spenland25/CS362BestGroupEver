

def calculateProbability(transmitPercentage,infected):
 #lets say that if infected, then the rate of that person infecting others is just 6% = 0.06.
 #transmitPercentage is the location percentage note for self

  if infected == True:
    #do .06 times whatever transmitPercentage is
    newPercent = transmitPercentage * 0.06
    print(newPercent)


transmitPercentage = .25
infected = False
calculateProbability(transmitPercentage, infected)